@echo off
rem LEExtractor portable launcher (v0.9.13). Keep this file CRLF.
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0"
title LEExtractor (portable)

set "LEEXTRACTOR_DATA_DIR=%~dp0data"
set "LEEXTRACTOR_MODEL_DIR=%~dp0models"
set "LEEXTRACTOR_CACHE_DIR=%~dp0cache"
set "LEEXTRACTOR_LOG_DIR=%~dp0logs"
set "LEEXTRACTOR_HOST=127.0.0.1"
set "LEEXTRACTOR_PORT=8012"
set "LEEXTRACTOR_LOG_FORMAT=text"
set "LEEXTRACTOR_MAX_ACTIVE_JOBS=1"
set "PYTHONPATH=%~dp0app"

for %%D in (data cache logs models) do if not exist "%%D" mkdir "%%D"

set "PYEXE="
if exist "runtime\python.exe" set "PYEXE=runtime\python.exe"
if not defined PYEXE if exist ".venv\Scripts\python.exe" set "PYEXE=.venv\Scripts\python.exe"
if defined PYEXE (
    %PYEXE% -c "import fastapi, uvicorn" >nul 2>&1
    if errorlevel 1 set "PYEXE="
)
if not defined PYEXE (
    python -c "import fastapi, uvicorn" >nul 2>&1
    if not errorlevel 1 set "PYEXE=python"
)
if not defined PYEXE (
    echo [1/2] 首次运行：创建本地环境并安装依赖（需要网络，几分钟）
    python -m venv .venv || goto failed
    set "PYEXE=.venv\Scripts\python.exe"
    !PYEXE! -m pip install --disable-pip-version-check --quiet "app" -c "app\constraints.txt" || goto failed
)

echo [2/2] 启动服务并打开浏览器： http://127.0.0.1:8012
echo 关闭本窗口即停止服务。
start "" /b cmd /c "timeout /t 4 /nobreak >nul & start http://127.0.0.1:8012"
%PYEXE% -m litsearch.web
goto end

:failed
echo.
echo 启动失败：请确认已安装 Python 3.10 以上，或把便携版 Python 放到 runtime\ 目录。
pause

:end
endlocal
