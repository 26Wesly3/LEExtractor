LEExtractor 便携版（Windows）
================================

双击 Start_LEExtractor.bat 即可：
  1. 启动后端（默认 http://127.0.0.1:8012）
  2. 自动打开浏览器
  3. 保持窗口打开即为运行中，关闭窗口即停止

目录说明
--------
  app\      程序源码（只读即可）
  runtime\  可选：便携版 Python（有则优先使用）
  models\   翻译 / Embedding 模型（可提前放好，比赛现场无需联网下载）
  data\     你的项目数据 —— 备份就备份这个目录
  cache\    检索缓存（删掉只是变慢）
  logs\     日志（自动轮转）

现场注意事项
------------
* 比赛演示优先用此本地版；云端版为 https://<子域>.duckdns.org（见 DEPLOYMENT.md）
* 没网也能用：模型已在 models\ 里、结果可以离线复算
* 端口被占用时：set LEEXTRACTOR_PORT=8013 后重新双击
* 升级：覆盖 app\ 目录后运行
      runtime\python.exe -m pip install --upgrade app
  即可；data\ 与 models\ 原样保留。runtime\ 已内置 Python 与依赖，现场无需联网。
