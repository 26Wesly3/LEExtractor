// 高清逐帧录制：边操作边截 PNG（无损），最后用 ffmpeg 编成 mp4。
// 输出：<dir>/C-从Zotero导入-帧/ 与 <dir>/D-插件一键导入-帧/
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const BASE = 'http://127.0.0.1:8000'
const DIR = path.join(ROOT, '03-从Zotero导入（含插件）')
const viewport = { width: 1920, height: 1080 }

const browser = await chromium.launch({ channel: 'chrome', headless: true })

async function record(name, steps) {
  const ctx = await browser.newContext({ viewport, deviceScaleFactor: 1 })
  const page = await ctx.newPage()
  page.setDefaultTimeout(120000)
  const framesDir = path.join(DIR, name + '-帧')
  fs.rmSync(framesDir, { recursive: true, force: true })
  fs.mkdirSync(framesDir, { recursive: true })

  let counting = true
  let index = 0
  const started = Date.now()
  const marks = []
  const mark = label => marks.push(`${String(Math.round((Date.now() - started) / 1000)).padStart(3)}s ${label}`)

  // 抓到停止为止：每帧一张无损 PNG。必须限速，否则会把 Chromium 打崩（0xC0000409）。
  const capture = (async () => {
    while (counting && index < 900) {
      const file = path.join(framesDir, `f${String(index).padStart(5, '0')}.png`)
      try { await page.screenshot({ path: file, scale: 'css' }) } catch { /* 页面切换瞬间可能失败 */ }
      index += 1
      await page.waitForTimeout(120)
    }
  })()

  const pause = ms => page.waitForTimeout(ms)
  await steps({ page, pause, mark })

  counting = false
  await capture
  const seconds = (Date.now() - started) / 1000
  await ctx.close()
  const meta = { name, frames: index, seconds: Number(seconds.toFixed(1)), fps: Number((index / seconds).toFixed(2)), marks }
  fs.writeFileSync(path.join(framesDir, 'meta.json'), JSON.stringify(meta, null, 2), 'utf8')
  console.log(JSON.stringify(meta))
}

await record('C-从Zotero导入', async ({ page, pause, mark }) => {
  await page.goto(`${BASE}/search`, { waitUntil: 'load' })
  await pause(1500)
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-import-start]')
  await pause(1500)
  mark('从已有文献开始')
  await page.click('[data-v32-zotero-import-start]')
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
  await pause(2200)
  mark('侧栏已连接与条目列表')
  const boxes = page.locator('[data-v32-zotero-item]')
  await boxes.nth(0).check()
  await pause(900)
  await boxes.nth(1).check()
  await pause(1300)
  mark('勾选两条')
  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 120000 })
  await pause(2200)
  mark('导入完成（元数据 + PDF）')
  await page.click('[data-v32-zotero-drawer-close]')
  await pause(900)
  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await page.waitForSelector('[data-v32-papers]')
  await pause(2000)
  await page.mouse.move(960, 620)
  await page.mouse.wheel(0, 460)
  await pause(1500)
  mark('导入后的项目')
})

await record('D-插件一键导入', async ({ page, pause, mark }) => {
  await page.goto(`${BASE}/search?zotero=1&item=24FNYDFP`, { waitUntil: 'load' })
  await pause(1800)
  mark('入口页（无侧栏）')
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
  await pause(2200)
  mark('侧栏自动预选该条目')
  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 120000 })
  await pause(2000)
  mark('导入完成')
})

await browser.close()
