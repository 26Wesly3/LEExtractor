// 补录：Zotero 插件点进来之后的那一段（入口页不展开侧栏 → 选路径 → 侧栏预选 → 导入）。
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const BASE = 'http://127.0.0.1:8000'
const dir = path.join(ROOT, '03-从Zotero导入（含插件）')
fs.mkdirSync(path.join(dir, '_raw'), { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, recordVideo: { dir: path.join(dir, '_raw'), size: { width: 1440, height: 900 } } })
const page = await ctx.newPage()
page.setDefaultTimeout(90000)
const start = Date.now()
const steps = []
const step = label => steps.push(`${String(Math.round((Date.now() - start) / 1000)).padStart(3)}s ${label}`)
const pause = ms => page.waitForTimeout(ms)

await page.goto(`${BASE}/search?zotero=1&item=24FNYDFP`, { waitUntil: 'load' })
await pause(1600)
const drawerOnEntry = await page.evaluate(() => Boolean(document.querySelector('[data-v32-zotero-drawer]')))
await page.screenshot({ path: path.join(dir, 'D1-插件点进来的入口页.png') })
step(`入口页（侧栏是否展开=${drawerOnEntry}）`)

await page.click('[data-v32-entry-action="pdf"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
await pause(1800)
const preselected = await page.evaluate(() => document.querySelectorAll('[data-v32-zotero-item]:checked').length)
await page.screenshot({ path: path.join(dir, 'D2-侧栏自动预选条目.png') })
step(`侧栏打开并预选（预选 ${preselected} 条）`)

await page.click('[data-v32-zotero-import]')
await page.waitForSelector('[data-v32-zotero-message]', { timeout: 90000 })
await pause(1400)
const message = (await page.locator('[data-v32-zotero-message]').textContent())?.trim()
await page.screenshot({ path: path.join(dir, 'D3-从插件导入完成.png') })
step(`导入完成：${message}`)

const video = ctx.pages()[0]?.video()
await ctx.close()
const raw = await video?.path().catch(() => null)
if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(dir, 'D-插件一键导入-完整流程.webm'))
fs.writeFileSync(path.join(ROOT, 'record-log-d.json'), JSON.stringify({ scene: 'D-插件一键导入', steps }, null, 2), 'utf8')
console.log(JSON.stringify({ drawerOnEntry, preselected, message, steps }, null, 2))
await browser.close()
