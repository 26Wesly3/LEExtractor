// 干净版全流程网页段：入口页 → 侧栏自动预选 → 导入完成（不回显任何浏览器界面）。
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const ITEM = process.argv[3] || '24FNYDFP'
const BASE = 'http://127.0.0.1:8000'
const dir = path.join(ROOT, '03-从Zotero导入（含插件）')
fs.mkdirSync(dir, { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, recordVideo: { dir, size: { width: 1920, height: 1080 } } })
const page = await ctx.newPage()
page.setDefaultTimeout(120000)
const pause = ms => page.waitForTimeout(ms)

await page.goto(`${BASE}/search?zotero=1&item=${encodeURIComponent(ITEM)}`, { waitUntil: 'load' })
await pause(1600)
await page.click('[data-v32-entry-action="pdf"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
await pause(2200)
const preselected = await page.evaluate(() => document.querySelectorAll('[data-v32-zotero-item]:checked').length)
await page.click('[data-v32-zotero-import]')
await page.waitForSelector('[data-v32-zotero-message]', { timeout: 120000 })
const message = (await page.locator('[data-v32-zotero-message]').textContent())?.trim()
await pause(2000)
await page.click('[data-v32-zotero-drawer-close]')
await pause(800)
await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
await page.waitForSelector('[data-v32-papers]')
await pause(2200)

const video = ctx.pages()[0]?.video()
await ctx.close()
const raw = await video?.path().catch(() => null)
if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(dir, 'F-网页端导入完成.webm'))
console.log(JSON.stringify({ preselected, message }, null, 2))
await browser.close()
