// 高清重录：从 Zotero 导入（网页侧栏 C + 插件落点 D）。
// 视口 1920×1080、设备像素比 2，录制 1920×1080，转码时用高码率。
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const BASE = 'http://127.0.0.1:8000'
const dir = path.join(ROOT, '03-从Zotero导入（含插件）')
fs.mkdirSync(path.join(dir, '_raw'), { recursive: true })

const viewport = { width: 1920, height: 1080 }
const browser = await chromium.launch({ channel: 'chrome', headless: true })
const log = []

async function record(name, steps) {
  const ctx = await browser.newContext({
    viewport,
    deviceScaleFactor: 2,
    recordVideo: { dir: path.join(dir, '_raw'), size: viewport },
  })
  const page = await ctx.newPage()
  page.setDefaultTimeout(120000)
  const started = Date.now()
  const marks = []
  const mark = label => marks.push(`${String(Math.round((Date.now() - started) / 1000)).padStart(3)}s ${label}`)
  const pause = ms => page.waitForTimeout(ms)
  const shot = file => page.screenshot({ path: path.join(dir, file) })

  await steps({ page, pause, mark, shot })

  const video = ctx.pages()[0]?.video()
  await ctx.close()
  const raw = await video?.path().catch(() => null)
  if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(dir, name))
  log.push({ scene: name, seconds: Math.round((Date.now() - started) / 1000), marks })
  console.log(name, Math.round((Date.now() - started) / 1000) + 's')
}

// C：网页侧栏导入（含 PDF）
await record('C-从Zotero导入-高清.webm', async ({ page, pause, mark, shot }) => {
  await page.goto(`${BASE}/search`, { waitUntil: 'load' })
  await pause(1800)
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-import-start]')
  await pause(1800)
  mark('从已有文献开始')
  await page.click('[data-v32-zotero-import-start]')
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
  await pause(2400)
  await shot('C1-Zotero侧栏已连接-高清.png')
  mark('侧栏已连接与条目列表')

  const boxes = page.locator('[data-v32-zotero-item]')
  await boxes.nth(0).check()
  await pause(900)
  await boxes.nth(1).check()
  await pause(1400)
  await shot('C2-勾选条目-高清.png')
  mark('勾选两条')

  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 120000 })
  await pause(2200)
  await shot('C3-导入完成含PDF-高清.png')
  mark('导入完成（元数据 + PDF）')

  await page.click('[data-v32-zotero-drawer-close]')
  await pause(900)
  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await page.waitForSelector('[data-v32-papers]')
  await pause(2200)
  await page.mouse.move(960, 600)
  await page.mouse.wheel(0, 420)
  await pause(1600)
  await shot('C4-导入后的项目-高清.png')
  mark('导入后的项目')
})

// D：插件点进来的落点（预选 → 导入）
await record('D-插件一键导入-高清.webm', async ({ page, pause, mark, shot }) => {
  await page.goto(`${BASE}/search?zotero=1&item=24FNYDFP`, { waitUntil: 'load' })
  await pause(2000)
  await shot('D1-插件点进来的入口页-高清.png')
  mark('入口页（无侧栏）')
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
  await pause(2400)
  await shot('D2-侧栏自动预选条目-高清.png')
  mark('侧栏自动预选该条目')
  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 120000 })
  await pause(2000)
  await shot('D3-从插件导入完成-高清.png')
  mark('导入完成')
})

fs.writeFileSync(path.join(ROOT, 'record-log-hd.json'), JSON.stringify(log, null, 2), 'utf8')
await browser.close()
