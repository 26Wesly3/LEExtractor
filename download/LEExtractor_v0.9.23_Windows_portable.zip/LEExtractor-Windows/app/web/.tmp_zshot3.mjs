import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const BASE = 'http://127.0.0.1:8000'
const OUT = path.join('..', 'docs', 'demo', 'screenshots')

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const problems = []
page.on('pageerror', e => problems.push(`pageerror: ${e.message}`))
page.on('console', m => { if (m.type() === 'error') problems.push(`console: ${m.text()}`) })

await page.goto(`${BASE}/search`, { waitUntil: 'load' })
await page.click('[data-v32-entry-action="pdf"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'), { timeout: 30000 })
await page.waitForSelector('[data-v32-import-options]', { timeout: 20000 })
await page.click('[data-v32-zotero-import-start]')
await page.waitForSelector('[data-v32-zotero-items]', { timeout: 20000 })
await page.waitForTimeout(1200)

// 选前两条并导入
const boxes = page.locator('[data-v32-zotero-item]')
await boxes.nth(0).check()
await boxes.nth(1).check()
const buttonText = await page.locator('[data-v32-zotero-import]').textContent()
await page.click('[data-v32-zotero-import]')

// 等结果行出现（导入 + 建批次）
let message = ''
for (let i = 0; i < 40; i += 1) {
  await page.waitForTimeout(1000)
  message = (await page.locator('[data-v32-zotero-message]').textContent().catch(() => '')) || ''
  const error = (await page.locator('[data-v32-zotero-error]').textContent().catch(() => '')) || ''
  if (message || error) { message = message || `ERROR: ${error}`; break }
}
await page.screenshot({ path: path.join(OUT, '10-zotero-import-pdf.png') })
console.log(JSON.stringify({ buttonText: buttonText?.trim(), message, problems }, null, 2))
await browser.close()
