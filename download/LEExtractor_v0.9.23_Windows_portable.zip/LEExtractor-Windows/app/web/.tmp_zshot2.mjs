import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const BASE = 'http://127.0.0.1:8000'
const OUT = path.join('..', 'docs', 'demo', 'screenshots')
fs.mkdirSync(OUT, { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const problems = []
page.on('pageerror', e => problems.push(`pageerror: ${e.message}`))
page.on('console', m => { if (m.type() === 'error') problems.push(`console: ${m.text()}`) })

await page.goto(`${BASE}/search`, { waitUntil: 'load' })
// 从已有文献开始 → PDF 入口
await page.click('[data-v32-entry-action="pdf"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'), { timeout: 30000 })
await page.waitForSelector('[data-v32-import-options]', { timeout: 20000 })
await page.click('[data-v32-zotero-import-start]')
await page.waitForSelector('[data-v32-zotero-drawer]', { timeout: 15000 })
await page.waitForTimeout(1500)

const info = await page.evaluate(() => {
  const button = document.querySelector('[data-v32-zotero-import]')
  const style = button ? getComputedStyle(button) : null
  return {
    buttonText: button?.textContent?.trim() || '',
    buttonBackground: style?.backgroundColor || '',
    buttonBorder: style?.borderTopColor || '',
    buttonHeight: style?.height || '',
    statusLine: document.querySelector('[data-v32-zotero-hint]')?.textContent?.trim() || '',
    hasReadonlyLine: document.body.textContent.includes('只读'),
    items: document.querySelectorAll('[data-v32-zotero-item]').length,
  }
})
await page.screenshot({ path: path.join(OUT, '10-zotero-import-pdf.png') })
console.log(JSON.stringify({ ...info, problems }, null, 2))
await browser.close()
