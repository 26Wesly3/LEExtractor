// 录三条路的真实操作素材：每条路一段连续录屏（webm）+ 关键截图 + 时间码清单。
// 用法：node record-material.mjs <输出根目录> <上传用 PDF 路径>
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const PDF = process.argv[3]
const BASE = 'http://127.0.0.1:8000'
const log = []

function folder(name) {
  const dir = path.join(ROOT, name)
  fs.mkdirSync(path.join(dir, '_raw'), { recursive: true })
  return dir
}

const pause = (page, ms = 700) => page.waitForTimeout(ms)

async function shoot(page, dir, name) {
  await page.screenshot({ path: path.join(dir, name) })
}

async function finishScene(context, dir, finalName, sceneStart, steps) {
  const video = context.pages()[0]?.video()
  await context.close()
  const raw = await video?.path().catch(() => null)
  if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(dir, finalName))
  const total = Math.round((Date.now() - sceneStart) / 1000)
  log.push({ scene: finalName, seconds: total, steps })
  console.log(`[${finalName}] ${total}s`, steps.slice(0, 6))
}

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const viewport = { width: 1440, height: 900 }

// ---------- 01 从研究方向开始 ----------
{
  const dir = folder('01-从研究方向开始')
  const ctx = await browser.newContext({ viewport, recordVideo: { dir: path.join(dir, '_raw'), size: viewport } })
  const page = await ctx.newPage()
  page.setDefaultTimeout(90000)
  const start = Date.now()
  const steps = []
  const step = label => steps.push(`${String(Math.round((Date.now() - start) / 1000)).padStart(3)}s ${label}`)

  await page.goto(`${BASE}/search`, { waitUntil: 'load' })
  await pause(page, 1400)
  await shoot(page, dir, 'A1-入口两条路.png')
  step('入口：两条路的选择')

  await page.click('[data-v32-entry-action="topic"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-research-text]')
  await pause(page, 900)
  step('进入「从研究方向开始」')

  await page.click('[data-v32-research-text]')
  await page.keyboard.type('薄荷干旱胁迫的转录组响应与次生代谢', { delay: 45 })
  await pause(page, 900)
  await shoot(page, dir, 'A2-输入研究方向.png')
  step('输入中文研究方向')

  await page.click('[data-v32-discover]')
  await pause(page, 1500)
  await page.waitForSelector('[data-v32-progress]', { timeout: 30000 }).catch(() => {})
  await shoot(page, dir, 'A3-检索进行中.png')
  step('开始发现：进度与来源')

  const deadline = Date.now() + 180000
  while (Date.now() < deadline) {
    const done = await page.evaluate(() => !document.querySelector('[data-v32-progress]') && document.querySelectorAll('.le32-card').length > 0)
    if (done) break
    await page.waitForTimeout(2000)
  }
  await pause(page, 1200)
  await shoot(page, dir, 'A4-推荐列表与理由.png')
  step('结果：核心文献 + 推荐理由')

  await page.mouse.move(700, 500)
  await page.mouse.wheel(0, 620)
  await pause(page, 1200)

  await page.locator('.le32-card-open').first().click().catch(() => {})
  await pause(page, 1500)
  await shoot(page, dir, 'A5-文献详情抽屉.png')
  step('文献详情：判断与依据')
  await page.keyboard.press('Escape')
  await pause(page, 800)

  await page.locator('[data-v32-judge="core"]').first().click().catch(() => {})
  await pause(page, 900)
  step('标记核心：判断留痕')

  await page.click('.le-nav-stage:has-text("研究领域概述")')
  await pause(page, 1800)
  await page.mouse.wheel(0, 420)
  await pause(page, 1200)
  await shoot(page, dir, 'A6-研究领域概述.png')
  step('研究领域概述：事实、期刊、时间线')

  await page.click('.le-nav-stage:has-text("创新点探索")')
  await pause(page, 1800)
  await shoot(page, dir, 'A7-创新点探索.png')
  step('创新点探索')

  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await pause(page, 1000)
  await page.click('[data-v32-export-toggle]').catch(() => {})
  await pause(page, 1600)
  await shoot(page, dir, 'A8-导出菜单.png')
  step('导出：五种格式')

  await finishScene(ctx, dir, 'A-从研究方向开始-完整流程.webm', start, steps)
}

// ---------- 02 从已有文献开始 ----------
{
  const dir = folder('02-从已有文献开始')
  const ctx = await browser.newContext({ viewport, recordVideo: { dir: path.join(dir, '_raw'), size: viewport } })
  const page = await ctx.newPage()
  page.setDefaultTimeout(120000)
  const start = Date.now()
  const steps = []
  const step = label => steps.push(`${String(Math.round((Date.now() - start) / 1000)).padStart(3)}s ${label}`)

  await page.goto(`${BASE}/search`, { waitUntil: 'load' })
  await pause(page, 1200)
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-import-options]')
  await pause(page, 1200)
  await shoot(page, dir, 'B1-上传入口与Zotero入口.png')
  step('从已有文献开始：上传 PDF 或 Zotero')

  if (PDF && fs.existsSync(PDF)) {
    await page.setInputFiles('input[type=file]', PDF)
    await pause(page, 1200)
    step('选择本地 PDF')
    await page.locator('button:has-text("导入并发现文献")').first().click().catch(() => {})
    await pause(page, 2500)
    await shoot(page, dir, 'B2-解析与匹配中.png')
    step('逐文件解析与匹配')
    // 等批次结束
    for (let i = 0; i < 40; i += 1) {
      const busy = await page.evaluate(() => !!document.querySelector('[data-v32-upload-busy], [aria-busy="true"]'))
      if (!busy) break
      await page.waitForTimeout(2000)
    }
    await pause(page, 1200)
    await shoot(page, dir, 'B3-匹配结果.png')
    step('匹配结果：本地种子/待确认')
  }

  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await page.waitForSelector('[data-v32-papers]')
  await pause(page, 1500)
  await shoot(page, dir, 'B4-进入核心文献.png')
  step('进入核心文献筛选推荐')

  await page.click('[data-v32-continue]').catch(() => {})
  await pause(page, 1500)
  step('基于当前文献继续发现（开始）')
  const deadline = Date.now() + 180000
  while (Date.now() < deadline) {
    const state = await page.evaluate(() => ({
      progress: !!document.querySelector('[data-v32-progress]'),
      cards: document.querySelectorAll('.le32-card').length,
    }))
    if (!state.progress && state.cards > 0) break
    await page.waitForTimeout(2000)
  }
  await pause(page, 1500)
  await shoot(page, dir, 'B5-发现结果.png')
  step('发现结果出现，列表可读')

  await finishScene(ctx, dir, 'B-从已有文献开始-完整流程.webm', start, steps)
}

// ---------- 03 从 Zotero 导入（含插件）----------
{
  const dir = folder('03-从Zotero导入（含插件）')
  const ctx = await browser.newContext({ viewport, recordVideo: { dir: path.join(dir, '_raw'), size: viewport } })
  const page = await ctx.newPage()
  page.setDefaultTimeout(90000)
  const start = Date.now()
  const steps = []
  const step = label => steps.push(`${String(Math.round((Date.now() - start) / 1000)).padStart(3)}s ${label}`)

  await page.goto(`${BASE}/search`, { waitUntil: 'load' })
  await pause(page, 1200)
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-import-start]')
  await pause(page, 1000)
  step('从已有文献开始：两条来源')

  await page.click('[data-v32-zotero-import-start]')
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 30000 })
  await pause(page, 1600)
  await shoot(page, dir, 'C1-Zotero侧栏已连接.png')
  step('侧栏：本机 Zotero 已连接、条目列表')

  const boxes = page.locator('[data-v32-zotero-item]')
  await boxes.nth(0).check()
  await pause(page, 700)
  await boxes.nth(1).check()
  await pause(page, 1000)
  await shoot(page, dir, 'C2-勾选条目.png')
  step('勾选要导入的文献')

  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 90000 })
  await pause(page, 1400)
  await shoot(page, dir, 'C3-导入完成含PDF.png')
  step('导入：元数据 + PDF')

  await page.click('[data-v32-zotero-drawer-close]')
  await pause(page, 800)
  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await page.waitForSelector('[data-v32-papers]')
  await pause(page, 1800)
  await page.mouse.wheel(0, 500)
  await pause(page, 1200)
  await shoot(page, dir, 'C4-导入后的项目.png')
  step('导入后的项目：文献已在列表里')

  await finishScene(ctx, dir, 'C-从Zotero导入-完整流程.webm', start, steps)
}

fs.writeFileSync(path.join(ROOT, 'record-log.json'), JSON.stringify(log, null, 2), 'utf8')
console.log('done')
await browser.close()
