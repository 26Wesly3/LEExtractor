// 录两段：I = 首页展示；J = 文献详情里的「获取全文」（出版社原文 / DOI 解析 / 机构入口）。
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const BASE = 'http://127.0.0.1:8000'
const HOME = path.join(ROOT, '05-首页展示')
const FULL = path.join(ROOT, '06-获取全文（图书馆入口）')
fs.mkdirSync(HOME, { recursive: true })
fs.mkdirSync(FULL, { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const log = []

async function scene(dir, name, steps) {
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, recordVideo: { dir, size: { width: 1920, height: 1080 } } })
  const page = await ctx.newPage()
  page.setDefaultTimeout(120000)
  const pause = ms => page.waitForTimeout(ms)
  const shot = file => page.screenshot({ path: path.join(dir, file) })
  const started = Date.now()
  const marks = []
  const mark = label => marks.push(`${String(Math.round((Date.now() - started) / 1000)).padStart(3)}s ${label}`)
  try {
    await steps({ page, pause, shot, mark })
  } catch (error) {
    marks.push(`ERROR: ${error.message}`)
    await shot(`${name}-失败截图.png`).catch(() => {})
  }
  const video = ctx.pages()[0]?.video()
  await ctx.close()
  const raw = await video?.path().catch(() => null)
  if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(dir, name + '.webm'))
  log.push({ scene: name, seconds: Math.round((Date.now() - started) / 1000), marks })
  console.log(JSON.stringify(log[log.length - 1]))
}

// I. 首页展示：整页滚动 + 停留
await scene(HOME, 'I-首页展示', async ({ page, pause, shot, mark }) => {
  await page.goto(BASE + '/', { waitUntil: 'load' })
  await pause(2200)
  await shot('I1-首页首屏.png')
  mark('首页首屏')

  const height = await page.evaluate(() => document.body.scrollHeight)
  for (const [i, y] of [420, 900, 1400, 1900].entries()) {
    await page.mouse.move(960, 700)
    await page.mouse.wheel(0, 420)
    await pause(1400)
    if (i === 1) await shot('I2-首页中部.png')
    if (y > height) break
  }
  await pause(800)
  await shot('I3-首页下部.png')
  mark('向下浏览首页')

  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'smooth' }))
  await pause(2000)
  await page.mouse.move(820, 560)
  await pause(1600)
  await shot('I4-首页入口区.png')
  mark('回到首屏')
})

// J. 获取全文：建项目 → 从 Zotero 导一条 → 打开详情 → 获取全文
await scene(FULL, 'J-获取全文', async ({ page, pause, shot, mark }) => {
  await page.goto(BASE + '/search', { waitUntil: 'load' })
  await pause(1200)
  await page.click('[data-v32-entry-action="pdf"]')
  await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
  await page.waitForSelector('[data-v32-zotero-import-start]')
  await pause(800)
  await page.click('[data-v32-zotero-import-start]')
  await page.waitForSelector('[data-v32-zotero-items]', { timeout: 40000 })
  await pause(1500)
  await page.locator('[data-v32-zotero-item]').first().check()
  await pause(700)
  await page.click('[data-v32-zotero-import]')
  await page.waitForSelector('[data-v32-zotero-message]', { timeout: 90000 })
  await pause(1500)
  mark('导入一条文献')

  await page.click('[data-v32-zotero-drawer-close]')
  await pause(700)
  await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
  await page.waitForSelector('[data-v32-papers]')
  await pause(1200)
  // 导入的条目没有主题证据，落在「探索/全部」，默认「推荐」是空的。
  const allView = page.locator('[data-v32-view="all"]')
  if (await allView.count()) {
    await allView.click()
    await pause(1200)
  }
  await page.waitForSelector('.le32-card-open', { timeout: 20000 })
  await page.locator('.le32-card-open').first().click()
  await page.waitForSelector('[data-v32-drawer]')
  await pause(1600)
  mark('打开文献详情')

  // 滚到「获取全文」
  for (let i = 0; i < 8; i += 1) {
    const visible = await page.locator('h4:has-text("获取全文")').isVisible().catch(() => false)
    if (visible) break
    await page.mouse.move(1500, 600)
    await page.mouse.wheel(0, 500)
    await pause(700)
  }
  await pause(1500)
  await shot('J1-获取全文三段入口.png')
  mark('获取全文入口')

  const links = page.locator('[data-v32-access] a, [data-v32-access-link]')
  const count = await links.count()
  if (count) {
    await links.first().hover()
    await pause(1500)
  }
  await shot('J2-入口说明.png')
  mark('入口说明（不代登录）')
})

fs.writeFileSync(path.join(ROOT, 'record-log-home-fulltext.json'), JSON.stringify(log, null, 2), 'utf8')
await browser.close()
