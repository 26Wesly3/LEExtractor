import { chromium } from 'playwright'
import path from 'node:path'

const BASE = 'http://127.0.0.1:8000'
const OUT = path.join('..', 'docs', 'demo', 'screenshots')
const t0 = Date.now()
const marks = []
const mark = label => marks.push(`${String(Date.now() - t0).padStart(6)}ms  ${label}`)

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } })
const problems = []
page.on('pageerror', e => problems.push(`pageerror: ${e.message}`))
page.on('console', m => { if (m.type() === 'error') problems.push(`console: ${m.text()}`) })
page.on('requestfinished', async req => {
  const url = req.url()
  if (!url.includes('/api/v3/')) return
  const timing = req.timing()
  const ms = Math.round(timing.responseEnd - timing.requestStart)
  if (ms > 800) marks.push(`  slow: ${ms}ms ${req.method()} ${url.replace(BASE, '')}`)
})

await page.goto(`${BASE}/search`, { waitUntil: 'load' })
mark('entry loaded')

await page.click('[data-v32-entry-action="pdf"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'), { timeout: 30000 })
mark('project created')

await page.waitForSelector('[data-v32-zotero-import-start]', { timeout: 20000 })
mark('pdf stage ready')

await page.click('[data-v32-zotero-import-start]')
await page.waitForSelector('[data-v32-zotero-items]', { timeout: 25000 })
mark('zotero side panel items loaded')

const boxes = page.locator('[data-v32-zotero-item]')
await boxes.nth(0).check()
await boxes.nth(1).check()
await page.click('[data-v32-zotero-import]')
await page.waitForSelector('[data-v32-zotero-message]', { timeout: 60000 })
const message = (await page.locator('[data-v32-zotero-message]').textContent())?.trim()
mark(`import done: ${message}`)
await page.screenshot({ path: path.join(OUT, '11-import-done.png') })

// 关闭侧栏，进入核心文献
await page.click('[data-v32-zotero-drawer-close]')
await page.click('.le-nav-stage:has-text("核心文献筛选推荐")')
await page.waitForSelector('[data-v32-papers]', { timeout: 20000 })
mark('papers stage')

const continueButton = page.locator('[data-v32-continue]')
await continueButton.click()
mark('clicked 基于当前文献继续发现 (开始)')

// 等到进度条消失或出现卡片
const deadline = Date.now() + 120000
let finished = false
while (Date.now() < deadline) {
  const state = await page.evaluate(() => ({
    progress: !!document.querySelector('[data-v32-progress]'),
    cards: document.querySelectorAll('.le32-card').length,
    error: document.querySelector('[data-v32-error]')?.textContent?.trim() || '',
    notice: document.querySelector('[data-v32-notice]')?.textContent?.trim() || '',
  }))
  if (state.error) { mark(`error: ${state.error}`); break }
  if (!state.progress && state.cards > 0) { finished = true; mark(`discovery settled, cards=${state.cards}`); break }
  await page.waitForTimeout(2000)
}
if (!finished) {
  const state = await page.evaluate(() => ({
    progress: document.querySelector('[data-v32-progress]')?.textContent?.trim() || '',
    notice: document.querySelector('[data-v32-notice]')?.textContent?.trim() || '',
  }))
  mark(`discovery did NOT settle in 120s: progress="${state.progress}" notice="${state.notice}"`)
}
await page.screenshot({ path: path.join(OUT, '12-after-start.png') })
console.log(marks.join('\n'))
console.log('problems:', JSON.stringify(problems.slice(0, 6)))
await browser.close()
