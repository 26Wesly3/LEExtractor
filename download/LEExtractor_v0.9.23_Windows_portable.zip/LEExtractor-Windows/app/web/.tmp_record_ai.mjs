// 录 AI 增强全流程：设置里填 API-key → 检测并拉取模型 → 选模型 → 记住在本机 → 保存；
// 再回项目里开「AI 增强」跑一次检索。全程只有页面本身，无浏览器外观。
import { chromium } from 'playwright'
import fs from 'node:fs'
import path from 'node:path'

const ROOT = process.argv[2]
const KEY = process.argv[3]
const MODEL = process.argv[4] || 'deepseek-flash'
const BASE = 'http://127.0.0.1:8000'
const DIR = path.join(ROOT, '04-AI增强（API-key到增强检索）')
fs.mkdirSync(DIR, { recursive: true })

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const ctx = await browser.newContext({
  viewport: { width: 1920, height: 1080 },
  recordVideo: { dir: DIR, size: { width: 1920, height: 1080 } },
})
const page = await ctx.newPage()
page.setDefaultTimeout(180000)
const pause = ms => page.waitForTimeout(ms)
const shot = name => page.screenshot({ path: path.join(DIR, name) })
const marks = []
const t0 = Date.now()
const mark = label => marks.push(`${String(Math.round((Date.now() - t0) / 1000)).padStart(3)}s ${label}`)

// ---- 1. 设置：导入 API-key 并拉取模型 ----
await page.goto(`${BASE}/settings`, { waitUntil: 'load' })
await pause(1800)
mark('设置页')

const preset = page.locator('[data-settings-preset]')
if (await preset.count()) {
  await preset.selectOption('deepseek').catch(() => {})
  await pause(1200)
  mark('选服务商预设')
}

const baseField = page.locator('[data-settings-base-url]')
if (await baseField.count()) {
  await baseField.fill('https://api.deepseek.com')
  await pause(900)
}

const keyField = page.locator('[data-settings-secret="ai_model"]')
await keyField.fill(KEY)
await pause(1200)
await shot('H1-填入API-key.png')
mark('填入 API-key')

const probe = page.locator('[data-settings-probe]')
if (await probe.count()) {
  await probe.click()
  await pause(3500)
  marks.push(`probe done at ${Math.round((Date.now() - t0) / 1000)}s`)
}
await shot('H2-检测并拉取模型.png')
mark('检测并拉取模型')

const modelSelect = page.locator('[data-settings-model="ai_model"]')
if (await modelSelect.count()) {
  const tag = await modelSelect.first().evaluate(el => el.tagName).catch(() => '')
  if (tag === 'SELECT') await modelSelect.first().selectOption(MODEL).catch(() => {})
  else await modelSelect.first().fill(MODEL)
  await pause(1200)
}
const persist = page.locator('[data-settings-persist="ai_model"]')
if (await persist.count()) {
  const checked = await persist.first().isChecked().catch(() => false)
  if (!checked) await persist.first().check().catch(() => {})
  await pause(900)
}
const save = page.locator('[data-settings-save="ai_model"]')
if (await save.count()) {
  await save.click()
  await pause(2500)
}
await shot('H3-保存后已配置.png')
mark('保存配置')

// ---- 2. 项目里开 AI 增强跑检索 ----
await page.goto(`${BASE}/search`, { waitUntil: 'load' })
await pause(1500)
await page.click('[data-v32-entry-action="topic"]')
await page.waitForFunction(() => location.pathname.startsWith('/projects/'))
await page.waitForSelector('[data-v32-research-text]')
await pause(1200)
await page.click('[data-v32-research-text]')
await page.keyboard.type('薄荷干旱胁迫的转录组响应与次生代谢', { delay: 35 })
await pause(1000)
const aiMode = page.locator('[data-v32-mode="ai_enhanced"]')
if (await aiMode.count()) {
  await aiMode.click()
  await pause(1200)
}
await shot('H4-选择AI增强.png')
mark('选 AI 增强')

await page.click('[data-v32-discover]')
await pause(2000)
await shot('H5-增强检索进行中.png')
mark('开始发现（增强）')

const deadline = Date.now() + 240000
while (Date.now() < deadline) {
  const state = await page.evaluate(() => ({
    progress: !!document.querySelector('[data-v32-progress]'),
    cards: document.querySelectorAll('.le32-card').length,
  }))
  if (!state.progress && state.cards > 0) break
  await page.waitForTimeout(2500)
}
await pause(2000)
await page.mouse.move(960, 640)
await page.mouse.wheel(0, 420)
await pause(1500)
await shot('H6-增强排序结果.png')
mark('增强排序结果')

const notice = await page.evaluate(() => document.querySelector('[data-v32-degraded]')?.textContent?.trim() || '')
const video = ctx.pages()[0]?.video()
await ctx.close()
const raw = await video?.path().catch(() => null)
if (raw && fs.existsSync(raw)) fs.renameSync(raw, path.join(DIR, 'H-AI增强-全流程.webm'))
fs.writeFileSync(path.join(DIR, 'meta.json'), JSON.stringify({ marks, notice }, null, 2), 'utf8')
console.log(JSON.stringify({ marks, notice }, null, 2))
await browser.close()
