import { chromium } from 'playwright'
import fs from 'node:fs'

const browser = await chromium.launch({ channel: 'chrome', headless: true })
const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } })
await page.goto('http://127.0.0.1:8000/search', { waitUntil: 'load' })
console.log('loaded')
fs.mkdirSync('E:/tmp_frames_test', { recursive: true })
for (let i = 0; i < 5; i += 1) {
  await page.screenshot({ path: `E:/tmp_frames_test/f${i}.png` })
  await page.waitForTimeout(120)
}
console.log('5 shots ok')
await browser.close()
